function StateGame(){
	
	this.create = function(){
		var newImage = chao.helpers.createImage("Sticker", "sticker");
		this.add(newImage.entity);
		newImage.entity.alignToParent();
		newImage.entity.addComponent(new ComponentTemplate(this));

		var introText = "chao.js is working!\nversion " + chao.VERSION;
		var newText = chao.helpers.createText("Version Text", newImage.entity.width/2, 0, chao.font, introText, 23);
		newText.color = chao.colorCodes[7];
		newText.align = "center";
		newImage.entity.add(newText.entity);
		newText.entity.alignToParentVertically(1.0, 0.0, 10);
	}

	this.resize = function(){
		//
	}

	this.update = function(){
		if(chao.justPressed[chao.KEY_L]){
			chao.logHierarchy(this.rootEntity);
		}
	}

	this.draw = function(){
		//
	}

}