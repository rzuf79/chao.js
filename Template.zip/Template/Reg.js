/**
 * Handy, pre-built Registry class that can be used to store 
 * references.
 */
var Reg = {
	loadGame : false
}